package com.accenture.lkm.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class PaymentEntity {
	@Id
	private int paid_id;
	private int purchase_id;
	private String paid_type;
	private String cheque_no;
	private Date paid_date;
	private double paid_amount;
	private double balance;
	private String remarks;

	public int getPaid_id() {
		return paid_id;
	}

	public void setPaid_id(int paid_id) {
		this.paid_id = paid_id;
	}

	public int getPurchase_id() {
		return purchase_id;
	}

	public void setPurchase_id(int purchase_id) {
		this.purchase_id = purchase_id;
	}

	public String getPaid_type() {
		return paid_type;
	}

	public void setPaid_type(String paid_type) {
		this.paid_type = paid_type;
	}

	public String getCheque_no() {
		return cheque_no;
	}

	public void setCheque_no(String cheque_no) {
		this.cheque_no = cheque_no;
	}

	public Date getPaid_date() {
		return paid_date;
	}

	public void setPaid_date(Date paid_date) {
		this.paid_date = paid_date;
	}

	public double getPaid_amount() {
		return paid_amount;
	}

	public void setPaid_amount(double paid_amount) {
		this.paid_amount = paid_amount;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}
