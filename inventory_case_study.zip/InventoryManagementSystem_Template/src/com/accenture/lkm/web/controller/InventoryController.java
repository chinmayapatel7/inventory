package com.accenture.lkm.web.controller;

import org.springframework.stereotype.Controller;

@Controller
public class InventoryController {

	
}
