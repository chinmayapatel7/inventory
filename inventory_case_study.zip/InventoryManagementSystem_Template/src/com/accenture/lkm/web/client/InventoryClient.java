package com.accenture.lkm.web.client;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class InventoryClient {

	
	public List<String> getListOfVendors(){
		return new ArrayList();
	}
}
