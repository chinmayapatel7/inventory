package com.accenture.lkm.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.accenture.lkm.entity.PurchaseEntity;

public interface InventoryPurchaseDAO extends JpaRepository<PurchaseEntity, Integer> {

}
